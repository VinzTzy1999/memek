//KALO MAU NGERENAME PAKE CREDIT GUA YTIM PIATU
require("./Databases/module.js")

//========== Setting Owner ==========//
global.no = "6283840073203"
global.owner = "𝐃𝐀𝐍𝐓𝐙𝐘 𝐃.𝐄.𝐕"
global.bot = "𝐀𝐏𝐄𝐈𝐑𝐎𝐓𝐙𝐘"
global.v = "1.0"
global.welcome = true
global.autoread = true
global.anticall = false

//========= Setting Url Foto =========//
global.image = "https://files.catbox.moe/uzy521.jpg"

global.msg = {
"error": "Maaf Adanya Sistem Error Pada Fitur Ini!!",
"done": "Berhasil🕊", 
"wait": "Wait To Proses🕊", 
"owner": "`You Now Owner`", 
"developer": "`You Now Development`"
}
global.own = "Dantzy"
global.log = "⇝"
global.ch = "https://whatsapp.com/channel/0029VahUbrs90x2wGeaWAc14"
global.bot = "APEIROTZY"
global.ver = "𝟭.𝟬"
global.wa = "https://wa.me/6283840073203"
global.logo = "https://files.catbox.moe/g89936.jpg"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})